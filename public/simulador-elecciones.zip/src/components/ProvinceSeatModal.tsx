import React, { useEffect, useMemo, useState } from 'react';
import { Party, Constituency, ScenarioData } from '../data/parliamentData';

interface ProvinceSeatModalProps {
  constituency: Constituency | null;
  parties: Party[];
  scenario: ScenarioData;
  isSenado: boolean;
  onClose: () => void;
  onUpdateSeat: (constituencyId: string, partyId: string, value: number) => void;
  onClearProvince: (constituencyId: string) => void;
}

export const ProvinceSeatModal: React.FC<ProvinceSeatModalProps> = ({
  constituency,
  parties,
  scenario,
  isSenado,
  onClose,
  onUpdateSeat,
  onClearProvince
}) => {
  const [partySearch, setPartySearch] = useState('');

  // Close on Escape key press
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  // Prevent background scrolling while modal is open
  useEffect(() => {
    if (constituency) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [constituency]);

  const provData = useMemo(() => {
    if (!constituency) return {};
    return scenario[constituency.id] || {};
  }, [scenario, constituency]);

  if (!constituency) return null;

  // Calculate province totals
  let totalAssignedInProv = 0;
  parties.forEach((p) => {
    totalAssignedInProv += provData[p.id] || 0;
  });

  const remainingSeats = constituency.seats - totalAssignedInProv;
  const isComplete = remainingSeats === 0;
  const isOverAllocated = remainingSeats < 0;

  // Filter parties if user searches
  const filteredParties = parties.filter((p) => {
    if (!partySearch.trim()) return true;
    const q = partySearch.toLowerCase().trim();
    return (
      p.name.toLowerCase().includes(q) ||
      (p.fullName && p.fullName.toLowerCase().includes(q))
    );
  });

  const handleStep = (partyId: string, delta: number) => {
    const current = provData[partyId] || 0;
    onUpdateSeat(constituency.id, partyId, current + delta);
  };

  const handleInputChange = (partyId: string, valStr: string) => {
    const parsed = parseInt(valStr, 10);
    onUpdateSeat(constituency.id, partyId, isNaN(parsed) ? 0 : parsed);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/35 backdrop-blur-[2px] transition-opacity animate-in-view"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-title"
    >
      <div className="relative w-full max-w-[420px] bg-white rounded-2xl border border-[#e9e7e0] shadow-[0_20px_50px_rgba(20,20,20,0.18)] overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="p-4 bg-[#fafaf8] border-b border-[#e9e7e0] flex items-start justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <h3 id="modal-title" className="text-xl font-bold tracking-tight text-[#17171a] m-0">
                {constituency.name}
              </h3>
              {isComplete && (
                <span className="text-xs font-bold text-[#2e8b4f] bg-[#eef9f1] px-2 py-0.5 rounded-full">
                  Completa ✓
                </span>
              )}
            </div>
            <p className="text-xs text-[#77756d] m-0 mt-0.5">
              {constituency.seats} escaños en disputa
              {isSenado && ` · Máx. ${constituency.maxPerParty} por partido`}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-lg flex items-center justify-center text-[#77756d] hover:text-[#17171a] hover:bg-black/5 active:scale-95 transition-all cursor-pointer text-lg leading-none"
            aria-label="Cerrar ventana"
          >
            ✕
          </button>
        </div>

        {/* Mini Seat Distribution Strip */}
        <div className="px-4 py-3 bg-white border-b border-[#e9e7e0]">
          <div className="flex justify-between items-center text-xs mb-1.5 font-medium">
            <span className="text-[#17171a] tabular-nums">
              <b>{totalAssignedInProv}</b> de {constituency.seats} asignados
            </span>
            <span
              className={`tabular-nums font-semibold ${
                isOverAllocated
                  ? 'text-[#c4281c]'
                  : isComplete
                  ? 'text-[#2e8b4f]'
                  : 'text-[#77756d]'
              }`}
            >
              {isOverAllocated
                ? `Exceso de ${-remainingSeats}`
                : isComplete
                ? '0 sin asignar'
                : `${remainingSeats} sin asignar`}
            </span>
          </div>

          {/* Color representation bar */}
          <div className="flex h-2.5 rounded-full overflow-hidden bg-[#fafaf8] border border-[#e9e7e0]">
            {parties.map((p) => {
              const count = provData[p.id] || 0;
              if (count === 0) return null;
              const pct = (count / constituency.seats) * 100;
              return (
                <div
                  key={p.id}
                  style={{ width: `${pct}%`, backgroundColor: p.color }}
                  title={`${p.name}: ${count}`}
                  className="h-full transition-all duration-150"
                />
              );
            })}
          </div>
        </div>

        {/* Quick Party Search Input (if list has > 8 items) */}
        {parties.length > 8 && (
          <div className="px-4 pt-3 pb-1 bg-white">
            <input
              type="text"
              placeholder="Filtrar partido..."
              value={partySearch}
              onChange={(e) => setPartySearch(e.target.value)}
              className="w-full text-xs px-3 py-1.5 rounded-lg border border-[#e9e7e0] bg-[#fafaf8] text-[#17171a] placeholder-[#77756d] focus:outline-none focus:border-[#17171a] transition-all"
            />
          </div>
        )}

        {/* Scrollable Party List (avoids overly long popups) */}
        <div className="p-3 overflow-y-auto max-h-[300px] scrollbar-thin divide-y divide-[#e9e7e0]/70 flex-1">
          {filteredParties.map((p) => {
            const currentVal = provData[p.id] || 0;
            const hasSeats = currentVal > 0;
            const canIncrement = remainingSeats > 0 && currentVal < constituency.maxPerParty;
            const canDecrement = currentVal > 0;

            return (
              <div
                key={p.id}
                className={`py-2 px-2 flex items-center justify-between gap-3 rounded-lg transition-colors ${
                  hasSeats ? 'bg-[#fafaf8]' : 'hover:bg-[#fafaf8]/60'
                }`}
              >
                {/* Party identity */}
                <div className="flex items-center gap-2.5 min-w-0 flex-1">
                  <span
                    className="w-3 h-3 rounded-full shrink-0 shadow-inner"
                    style={{ backgroundColor: p.color }}
                  />
                  <div className="min-w-0">
                    <div className="text-xs font-semibold text-[#17171a] truncate">
                      {p.name}
                    </div>
                    {p.fullName && (
                      <div className="text-[11px] text-[#77756d] truncate">
                        {p.fullName}
                      </div>
                    )}
                  </div>
                </div>

                {/* Stepper Input */}
                <div
                  className="inline-flex items-center rounded-lg border border-[#e9e7e0] p-0.5 bg-white transition-all focus-within:border-[#17171a] focus-within:ring-2 focus-within:ring-[#17171a]/10 shrink-0"
                  style={{
                    backgroundColor: hasSeats ? `${p.color}14` : '#ffffff',
                    borderColor: hasSeats ? `${p.color}55` : undefined
                  }}
                >
                  <button
                    type="button"
                    tabIndex={-1}
                    disabled={!canDecrement}
                    onClick={() => handleStep(p.id, -1)}
                    className="w-6 h-6 rounded flex items-center justify-center text-xs font-bold text-[#77756d] hover:text-[#17171a] hover:bg-black/5 disabled:opacity-20 disabled:cursor-not-allowed cursor-pointer transition-colors"
                    aria-label={`Restar un escaño a ${p.name}`}
                  >
                    −
                  </button>
                  <input
                    type="number"
                    min={0}
                    max={Math.min(constituency.maxPerParty, currentVal + Math.max(0, remainingSeats))}
                    value={currentVal > 0 ? currentVal : ''}
                    placeholder="0"
                    onChange={(e) => handleInputChange(p.id, e.target.value)}
                    className="w-8 text-center text-xs font-bold text-[#17171a] tabular-nums bg-transparent border-0 outline-none p-0 [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                  />
                  <button
                    type="button"
                    tabIndex={-1}
                    disabled={!canIncrement}
                    onClick={() => handleStep(p.id, 1)}
                    className="w-6 h-6 rounded flex items-center justify-center text-xs font-bold text-[#77756d] hover:text-[#17171a] hover:bg-black/5 disabled:opacity-20 disabled:cursor-not-allowed cursor-pointer transition-colors"
                    aria-label={`Añadir un escaño a ${p.name}`}
                  >
                    +
                  </button>
                </div>
              </div>
            );
          })}
          {filteredParties.length === 0 && (
            <div className="py-6 text-center text-xs text-[#77756d]">
              No se encontraron partidos con ese nombre.
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-3 bg-[#fafaf8] border-t border-[#e9e7e0] flex items-center justify-between gap-2">
          <button
            type="button"
            onClick={() => onClearProvince(constituency.id)}
            disabled={totalAssignedInProv === 0}
            className="text-xs font-medium text-[#c4281c] hover:bg-[#fdf1ef] px-3 py-2 rounded-lg transition-colors cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed disabled:hover:bg-transparent"
          >
            Vaciar circunscripción
          </button>
          <button
            type="button"
            onClick={onClose}
            className="text-xs font-semibold px-4 py-2 rounded-lg bg-[#17171a] text-white hover:bg-[#34343a] active:scale-95 transition-all cursor-pointer"
          >
            Listo
          </button>
        </div>
      </div>
    </div>
  );
};
